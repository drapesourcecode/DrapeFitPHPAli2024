<?php

  namespace App\View\Cell;

  use Cake\View\Cell;


  /**
   * Users cell
   */
  class ChatCell extends Cell
   {

   protected $_validCellOptions = [];

   /**
    * Default display method.
    *
    * @return void
    * 
    * 
    * 
    */   
 }