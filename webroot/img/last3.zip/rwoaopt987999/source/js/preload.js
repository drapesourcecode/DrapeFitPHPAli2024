localStorage.clear();
setTimeout(function(){$("#loader").addClass("hidden");},3000);
fetch('https://api.ipify.org?format=json')
  .then(response => response.json())
  .then(data => localStorage.setItem("IP",data.ip)); 
  
 