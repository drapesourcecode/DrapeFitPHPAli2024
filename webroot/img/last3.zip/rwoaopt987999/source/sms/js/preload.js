
setTimeout(function(){$("#loader").addClass("hidden");},5000);

  
 